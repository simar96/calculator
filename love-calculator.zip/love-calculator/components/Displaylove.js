import React from 'react';
import { Text, View, StyleSheet } from 'react-native';

const Displaylove=(prop)=>{

if (prop.data=="Loding..."){
  return <Text  style={styles.text}> > Wait...</Text>
}
if (prop.data.message){
  return <Text  style={styles.text}> > Something went Wrong</Text>
}
 else{

  return(

    <View style={styles.container}>
<Text style={styles.text}> {prop.data.percentage}  </Text>
<Text style={styles.text}> {prop.data.result}</Text>
    </View>
  )
}

}

export default Displaylove

const styles = StyleSheet.create({
  container:{
    flex:1,
    backgroundColor: 'white',
    
  },
  text:{
    fontSize:25
  }
});